
package bank;


public class Bank {

    
    public static void main(String[] args) {
      Project m=new Project();
      m.setVisible(true);
         

    }

}
